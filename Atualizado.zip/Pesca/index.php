<?php
// Conexão com a base de dados
$mysqli = new mysqli("localhost", "root", "", "fishing_db");
if ($mysqli->connect_errno) {
    die("Falha na conexão: " . $mysqli->connect_error);
}

// --- CRUD: Adicionar ---
if(isset($_POST['add'])){
    $stmt = $mysqli->prepare("INSERT INTO catches (common_name, weight_kg, catch_date, fisher_id) VALUES (?,?,?,?)");
    $stmt->bind_param("sdsi", $_POST['common_name'], $_POST['weight_kg'], $_POST['catch_date'], $_POST['fisher_id']);
    $stmt->execute();
    header("Location: index.php");
    exit;
}

// --- CRUD: Editar ---
if(isset($_POST['update'])){
    $stmt = $mysqli->prepare("UPDATE catches SET common_name=?, weight_kg=?, catch_date=?, fisher_id=? WHERE id=?");
    $stmt->bind_param("sdsii", $_POST['common_name'], $_POST['weight_kg'], $_POST['catch_date'], $_POST['fisher_id'], $_POST['id']);
    $stmt->execute();
    header("Location: index.php");
    exit;
}

// --- CRUD: Eliminar ---
if(isset($_GET['delete'])){
    $stmt = $mysqli->prepare("DELETE FROM catches WHERE id=?");
    $stmt->bind_param("i", $_GET['delete']);
    $stmt->execute();
    header("Location: index.php");
    exit;
}

// --- Totais para os cartões ---
$totalCapturas = $mysqli->query("SELECT SUM(weight_kg) AS total FROM catches")->fetch_assoc()['total'] ?? 0;
$totalPescadores = $mysqli->query("SELECT COUNT(*) AS total FROM fishers")->fetch_assoc()['total'] ?? 0;
$totalEmbarcacoes = $mysqli->query("SELECT COUNT(*) AS total FROM boats")->fetch_assoc()['total'] ?? 0;
$totalVendas = $mysqli->query("SELECT SUM(amount) AS total FROM sales")->fetch_assoc()['total'] ?? 0;

// --- Últimas capturas ---
$catchesTable = $mysqli->query("SELECT c.id, c.common_name, c.weight_kg, c.catch_date, f.first_name, f.last_name 
                                FROM catches c
                                JOIN fishers f ON c.fisher_id = f.id
                                ORDER BY c.catch_date DESC
                                LIMIT 10");

// --- Dados para gráfico de área ---
$areaLabels = [];
$areaData = [];
$result = $mysqli->query("SELECT MONTH(catch_date) AS mes, SUM(weight_kg) AS total FROM catches GROUP BY MONTH(catch_date)");
while ($row = $result->fetch_assoc()) {
    $areaLabels[] = "Mês " . $row['mes'];
    $areaData[] = (float)$row['total'];
}

// --- Dados para gráfico de pizza ---
$pieLabels = [];
$pieData = [];
$resultPie = $mysqli->query("SELECT common_name, SUM(weight_kg) AS total FROM catches GROUP BY common_name");
while ($row = $resultPie->fetch_assoc()) {
    $pieLabels[] = $row['common_name'];
    $pieData[] = (float)$row['total'];
}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard da Pesca</title>
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <script src="vendor/chart.js/Chart.min.js"></script>
</head>
<body id="page-top">

<!-- Page Wrapper -->
<div id="wrapper">

    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
        <!-- Sidebar - Brand -->
        <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.php">
            <div class="sidebar-brand-icon rotate-n-15">
                <i class="fas fa-laugh-wink"></i>
            </div>
            <div class="sidebar-brand-text mx-3">SB Admin <sup>2</sup></div>
        </a>
        <hr class="sidebar-divider my-0">
        <li class="nav-item active">
            <a class="nav-link" href="index.php">
                <i class="fas fa-fw fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </a>
        </li>
        <hr class="sidebar-divider">
    </ul>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">

            <!-- Topbar -->
            <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 shadow">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item dropdown no-arrow">
                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                           data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="mr-2 d-none d-lg-inline text-gray-600 small">Douglas McGee</span>
                            <img class="img-profile rounded-circle" src="img/undraw_profile.svg">
                        </a>
                    </li>
                </ul>
            </nav>
            <!-- End of Topbar -->

            <!-- Begin Page Content -->
            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="d-sm-flex align-items-center justify-content-between mb-4">
                    <h1 class="h3 mb-0 text-gray-800">Dashboard da Pesca</h1>
                    <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                        <i class="fas fa-download fa-sm text-white-50"></i> Generate Report
                    </a>
                </div>

                <!-- Cards -->
                <div class="row">
                    <!-- Captura Total -->
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-primary shadow h-100 py-2">
                            <div class="card-body">
                                <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Captura Total (kg)</div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800"><?= number_format($totalCapturas,2) ?> kg</div>
                            </div>
                        </div>
                    </div>
                    <!-- Pescadores -->
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-success shadow h-100 py-2">
                            <div class="card-body">
                                <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Pescadores</div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $totalPescadores ?></div>
                            </div>
                        </div>
                    </div>
                    <!-- Embarcações -->
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-info shadow h-100 py-2">
                            <div class="card-body">
                                <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Embarcações</div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $totalEmbarcacoes ?></div>
                            </div>
                        </div>
                    </div>
                    <!-- Vendas -->
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-warning shadow h-100 py-2">
                            <div class="card-body">
                                <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Vendas (€)</div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800">€<?= number_format($totalVendas,2) ?></div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Gráficos -->
                <div class="row">
                    <!-- Gráfico de Área -->
                    <div class="col-xl-8 col-lg-7">
                        <div class="card shadow mb-4">
                            <div class="card-header py-3">
                                <h6 class="m-0 font-weight-bold text-primary">Produção de Peixe por Mês</h6>
                            </div>
                            <div class="card-body">
                                <canvas id="myAreaChart"></canvas>
                            </div>
                        </div>
                    </div>
                    <!-- Gráfico de Pizza -->
                    <div class="col-xl-4 col-lg-5">
                        <div class="card shadow mb-4">
                            <div class="card-header py-3">
                                <h6 class="m-0 font-weight-bold text-primary">Fontes de Captura</h6>
                            </div>
                            <div class="card-body">
                                <canvas id="myPieChart"></canvas>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Últimas Capturas -->
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Últimas Capturas</h6>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Espécie</th>
                                        <th>Peso (kg)</th>
                                        <th>Data</th>
                                        <th>Pescador</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while($row = $catchesTable->fetch_assoc()): ?>
                                    <tr>
                                        <td><?= $row['id'] ?></td>
                                        <td><?= $row['common_name'] ?></td>
                                        <td><?= $row['weight_kg'] ?></td>
                                        <td><?= $row['catch_date'] ?></td>
                                        <td><?= $row['first_name']." ".$row['last_name'] ?></td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- CRUD de Capturas -->
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Gerir Capturas</h6>
                    </div>
                    <div class="card-body">
                        <!-- Formulário de Inserção -->
                        <form method="post" action="index.php">
                            <div class="form-row">
                                <div class="form-group col-md-3">
                                    <label>Espécie</label>
                                    <input type="text" name="common_name" class="form-control" required>
                                </div>
                                <div class="form-group col-md-2">
                                    <label>Peso (kg)</label>
                                    <input type="number" step="0.01" name="weight_kg" class="form-control" required>
                                </div>
                                <div class="form-group col-md-3">
                                    <label>Data</label>
                                    <input type="date" name="catch_date" class="form-control" required>
                                </div>
                                <div class="form-group col-md-2">
                                    <label>Pescador ID</label>
                                    <input type="number" name="fisher_id" class="form-control" required>
                                </div>
                                <div class="form-group col-md-2 align-self-end">
                                    <button type="submit" name="add" class="btn btn-success btn-block">Adicionar</button>
                                </div>
                            </div>
                        </form>

                        <!-- Tabela de Capturas com Edit/Delete -->
                        <div class="table-responsive mt-4">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Espécie</th>
                                        <th>Peso (kg)</th>
                                        <th>Data</th>
                                        <th>Pescador ID</th>
                                        <th>Ações</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $captures = $mysqli->query("SELECT * FROM catches ORDER BY id DESC");
                                    while($c = $captures->fetch_assoc()):
                                    ?>
                                    <tr>
                                        <td><?= $c['id'] ?></td>
                                        <td><?= $c['common_name'] ?></td>
                                        <td><?= $c['weight_kg'] ?></td>
                                        <td><?= $c['catch_date'] ?></td>
                                        <td><?= $c['fisher_id'] ?></td>
                                        <td>
                                            <a href="crud.php?edit=<?= $c['id'] ?>" class="btn btn-warning btn-sm">Editar</a>
                                            <a href="index.php?delete=<?= $c['id'] ?>" class="btn btn-danger btn-sm">Eliminar</a>
                                        </td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

    </div>
    <!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<script>
    // Gráfico de Área
    var ctx = document.getElementById("myAreaChart").getContext('2d');
    var myLineChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: <?= json_encode($areaLabels) ?>,
            datasets: [{
                label: "Produção (kg)",
                data: <?= json_encode($areaData) ?>,
                borderColor: "rgba(78, 115, 223, 1)",
                backgroundColor: "rgba(78, 115, 223, 0.05)"
            }]
        }
    });

    // Gráfico de Pizza
    var ctx2 = document.getElementById("myPieChart").getContext('2d');
    var myPieChart = new Chart(ctx2, {
        type: 'doughnut',
        data: {
            labels: <?= json_encode($pieLabels) ?>,
            datasets: [{
                data: <?= json_encode($pieData) ?>,
                backgroundColor: ['#4e73df','#1cc88a','#36b9cc']
            }]
        },
        options: {cutoutPercentage: 60}
    });
</script>

<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="vendor/jquery-easing/jquery.easing.min.js"></script>
<script src="js/sb-admin-2.min.js"></script>
</body>
</html>
