-- Criar base de dados
CREATE DATABASE IF NOT EXISTS fishing_db;
USE fishing_db;

-- Tabela de pescadores
CREATE TABLE fishers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50)
);

INSERT INTO fishers (first_name, last_name) VALUES
('João', 'Silva'),
('Maria', 'Fernandes'),
('Pedro', 'Almeida');

-- Tabela de embarcações
CREATE TABLE boats (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50)
);

INSERT INTO boats (name) VALUES
('Mar Azul'),
('Vento Forte');

-- Tabela de capturas
CREATE TABLE catches (
    id INT AUTO_INCREMENT PRIMARY KEY,
    common_name VARCHAR(50),
    weight_kg DECIMAL(10,2),
    catch_date DATE,
    fisher_id INT,
    FOREIGN KEY (fisher_id) REFERENCES fishers(id)
);

INSERT INTO catches (common_name, weight_kg, catch_date, fisher_id) VALUES
('Sardinha', 50.5, '2025-09-01', 1),
('Atum', 120.3, '2025-09-02', 2),
('Bacalhau', 75.2, '2025-09-05', 3),
('Sardinha', 60.0, '2025-09-10', 1),
('Atum', 80.5, '2025-09-12', 2);

-- Tabela de vendas
CREATE TABLE sales (
    id INT AUTO_INCREMENT PRIMARY KEY,
    amount DECIMAL(10,2)
);

INSERT INTO sales (amount) VALUES
(500.00),
(750.00),
(1200.00);
