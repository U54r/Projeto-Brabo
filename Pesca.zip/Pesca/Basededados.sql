-- pesca_schema_seed.sql
-- Esquema e dados de exemplo para um sistema de gestão de pesca (MySQL / XAMPP)
-- Importar através do phpMyAdmin ou CLI: mysql -u root -p < pesca_schema_seed.sql

DROP DATABASE IF EXISTS pesca_db;
CREATE DATABASE pesca_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE pesca_db;

-- ==============================
-- TABELAS
-- ==============================

-- Pescadores / Tripulantes
CREATE TABLE fishermen (
  id INT AUTO_INCREMENT PRIMARY KEY,
  first_name VARCHAR(100) NOT NULL,
  last_name VARCHAR(100) NOT NULL,
  nif VARCHAR(20) UNIQUE,
  phone VARCHAR(30),
  email VARCHAR(100),
  address VARCHAR(255),
  experience_years INT DEFAULT 0,
  license_number VARCHAR(50),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Embarcações
CREATE TABLE vessels (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  registration VARCHAR(50) UNIQUE,
  vessel_type ENUM('Pesqueiro','Barco de Cerco','Lancha','Atuneiro','Outros') NOT NULL DEFAULT 'Pesqueiro',
  capacity_kg INT,
  home_port VARCHAR(100),
  captain_id INT NULL,
  active TINYINT(1) DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (captain_id) REFERENCES fishermen(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Espécies
CREATE TABLE species (
  id INT AUTO_INCREMENT PRIMARY KEY,
  common_name VARCHAR(100) NOT NULL,
  scientific_name VARCHAR(150),
  iucn_status VARCHAR(50),
  average_price_per_kg DECIMAL(8,2) DEFAULT 0.00,
  sustainable BOOLEAN DEFAULT TRUE,
  notes TEXT
) ENGINE=InnoDB;

-- Zonas de pesca
CREATE TABLE fishing_zones (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  code VARCHAR(20),
  description TEXT
) ENGINE=InnoDB;

-- Viagens (Trips)
CREATE TABLE trips (
  id INT AUTO_INCREMENT PRIMARY KEY,
  vessel_id INT NOT NULL,
  start_date DATE,
  end_date DATE,
  departure_port VARCHAR(100),
  return_port VARCHAR(100),
  crew_count INT,
  total_weight_kg DECIMAL(10,2) DEFAULT 0.00,
  notes TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (vessel_id) REFERENCES vessels(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Capturas (Catches)
CREATE TABLE catches (
  id INT AUTO_INCREMENT PRIMARY KEY,
  trip_id INT NULL,
  vessel_id INT NULL,
  fisherman_id INT NULL,
  species_id INT NOT NULL,
  zone_id INT NULL,
  catch_date DATE,
  weight_kg DECIMAL(8,2) DEFAULT 0.00,
  quantity INT DEFAULT 1,
  gear_type VARCHAR(50),
  price_per_kg DECIMAL(8,2) DEFAULT 0.00,
  quality_grade VARCHAR(20),
  notes TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (trip_id) REFERENCES trips(id) ON DELETE SET NULL,
  FOREIGN KEY (vessel_id) REFERENCES vessels(id) ON DELETE SET NULL,
  FOREIGN KEY (fisherman_id) REFERENCES fishermen(id) ON DELETE SET NULL,
  FOREIGN KEY (species_id) REFERENCES species(id) ON DELETE RESTRICT,
  FOREIGN KEY (zone_id) REFERENCES fishing_zones(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Vendas
CREATE TABLE sales (
  id INT AUTO_INCREMENT PRIMARY KEY,
  catch_id INT NULL,
  buyer VARCHAR(150),
  sale_date DATE,
  total_price DECIMAL(10,2),
  notes TEXT,
  FOREIGN KEY (catch_id) REFERENCES catches(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Licenças
CREATE TABLE licenses (
  id INT AUTO_INCREMENT PRIMARY KEY,
  fisherman_id INT NOT NULL,
  license_type VARCHAR(100),
  issue_date DATE,
  expiry_date DATE,
  status ENUM('active','expired','suspended') DEFAULT 'active',
  notes TEXT,
  FOREIGN KEY (fisherman_id) REFERENCES fishermen(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Trip crew (associação pescador <-> viagem)
CREATE TABLE trip_crew (
  trip_id INT NOT NULL,
  fisherman_id INT NOT NULL,
  role VARCHAR(50),
  PRIMARY KEY (trip_id, fisherman_id),
  FOREIGN KEY (trip_id) REFERENCES trips(id) ON DELETE CASCADE,
  FOREIGN KEY (fisherman_id) REFERENCES fishermen(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Índices úteis
CREATE INDEX idx_catches_date ON catches(catch_date);
CREATE INDEX idx_catches_species ON catches(species_id);
CREATE INDEX idx_trips_vessel ON trips(vessel_id);

-- ==============================
-- TRIGGERS: manter total_weight_kg em trips
-- ==============================
DELIMITER $$

CREATE TRIGGER trg_after_insert_catch
AFTER INSERT ON catches
FOR EACH ROW
BEGIN
  IF NEW.trip_id IS NOT NULL THEN
    UPDATE trips SET total_weight_kg = total_weight_kg + NEW.weight_kg WHERE id = NEW.trip_id;
  END IF;
END$$

CREATE TRIGGER trg_after_update_catch
AFTER UPDATE ON catches
FOR EACH ROW
BEGIN
  IF OLD.trip_id = NEW.trip_id THEN
    -- mesma viagem: ajusta diferença
    UPDATE trips SET total_weight_kg = total_weight_kg + (NEW.weight_kg - OLD.weight_kg) WHERE id = NEW.trip_id;
  ELSE
    -- peso removido da viagem antiga
    IF OLD.trip_id IS NOT NULL THEN
      UPDATE trips SET total_weight_kg = total_weight_kg - OLD.weight_kg WHERE id = OLD.trip_id;
    END IF;
    -- peso adicionado à nova viagem
    IF NEW.trip_id IS NOT NULL THEN
      UPDATE trips SET total_weight_kg = total_weight_kg + NEW.weight_kg WHERE id = NEW.trip_id;
    END IF;
  END IF;
END$$

CREATE TRIGGER trg_after_delete_catch
AFTER DELETE ON catches
FOR EACH ROW
BEGIN
  IF OLD.trip_id IS NOT NULL THEN
    UPDATE trips SET total_weight_kg = total_weight_kg - OLD.weight_kg WHERE id = OLD.trip_id;
  END IF;
END$$

DELIMITER ;

-- ==============================
-- PROCEDURES SIMPLES para ADD / UPDATE / DELETE (exemplos)
-- ==============================
DELIMITER $$

-- Adicionar pescador
CREATE PROCEDURE add_fisherman(
  IN p_first VARCHAR(100), IN p_last VARCHAR(100), IN p_nif VARCHAR(20), IN p_phone VARCHAR(30), IN p_email VARCHAR(100), IN p_address VARCHAR(255), IN p_exp INT, IN p_license VARCHAR(50)
)
BEGIN
  INSERT INTO fishermen(first_name,last_name,nif,phone,email,address,experience_years,license_number)
  VALUES(p_first,p_last,p_nif,p_phone,p_email,p_address,p_exp,p_license);
  SELECT LAST_INSERT_ID() AS inserted_id;
END$$

-- Atualizar pescador (exemplo simplificado)
CREATE PROCEDURE update_fisherman(
  IN p_id INT, IN p_first VARCHAR(100), IN p_last VARCHAR(100), IN p_phone VARCHAR(30), IN p_email VARCHAR(100)
)
BEGIN
  UPDATE fishermen SET first_name=p_first, last_name=p_last, phone=p_phone, email=p_email, updated_at=NOW() WHERE id=p_id;
  SELECT ROW_COUNT() AS affected_rows;
END$$

-- Eliminar pescador
CREATE PROCEDURE delete_fisherman(IN p_id INT)
BEGIN
  DELETE FROM fishermen WHERE id=p_id;
  SELECT ROW_COUNT() AS affected_rows;
END$$

-- Adicionar captura
CREATE PROCEDURE add_catch(
  IN p_trip_id INT, IN p_vessel_id INT, IN p_fisherman_id INT, IN p_species_id INT, IN p_zone_id INT,
  IN p_catch_date DATE, IN p_weight DECIMAL(8,2), IN p_quantity INT, IN p_gear VARCHAR(50), IN p_price DECIMAL(8,2), IN p_quality VARCHAR(20)
)
BEGIN
  INSERT INTO catches(trip_id,vessel_id,fisherman_id,species_id,zone_id,catch_date,weight_kg,quantity,gear_type,price_per_kg,quality_grade)
  VALUES(p_trip_id,p_vessel_id,p_fisherman_id,p_species_id,p_zone_id,p_catch_date,p_weight,p_quantity,p_gear,p_price,p_quality);
  SELECT LAST_INSERT_ID() AS inserted_id;
END$$

-- Atualizar captura (exemplo simplificado)
CREATE PROCEDURE update_catch(
  IN p_id INT, IN p_weight DECIMAL(8,2), IN p_quantity INT, IN p_price DECIMAL(8,2), IN p_quality VARCHAR(20)
)
BEGIN
  UPDATE catches SET weight_kg=p_weight, quantity=p_quantity, price_per_kg=p_price, quality_grade=p_quality WHERE id=p_id;
  SELECT ROW_COUNT() AS affected_rows;
END$$

-- Eliminar captura
CREATE PROCEDURE delete_catch(IN p_id INT)
BEGIN
  DELETE FROM catches WHERE id=p_id;
  SELECT ROW_COUNT() AS affected_rows;
END$$

DELIMITER ;

-- ==============================
-- VIEWS e RELATÓRIOS FÁCEIS
-- ==============================
CREATE VIEW vw_monthly_catches AS
SELECT DATE_FORMAT(catch_date, '%Y-%m') AS month, s.common_name AS species, s.scientific_name, SUM(c.weight_kg) AS total_weight_kg, COUNT(*) AS num_records
FROM catches c
JOIN species s ON c.species_id = s.id
GROUP BY month, c.species_id
ORDER BY month DESC, total_weight_kg DESC;

CREATE VIEW vw_top_species AS
SELECT s.common_name AS species, SUM(c.weight_kg) AS total_weight_kg
FROM catches c
JOIN species s ON c.species_id = s.id
GROUP BY c.species_id
ORDER BY total_weight_kg DESC
LIMIT 10;

-- ==============================
-- DADOS DE EXEMPLO (seed)
-- ==============================

-- Pescadores
INSERT INTO fishermen(first_name,last_name,nif,phone,email,address,experience_years,license_number) VALUES
('João','Silva','123456789','912345678','joao.silva@example.com','Rua do Mar 10, Porto',12,'LIC-PT-001'),
('Ana','Pereira','987654321','913333444','ana.pereira@example.com','Av. das Pescas 5, Matosinhos',8,'LIC-PT-002'),
('Carlos','Matos','234567890','914444555','carlos.matos@example.com','Praia Grande, Setúbal',20,'LIC-PT-003'),
('Sofia','Alves','345678901','915555666','sofia.alves@example.com','Ilha Azul, Açores',5,'LIC-PT-004'),
('Pedro','Gomes','456789012','916666777','pedro.gomes@example.com','Vila Nova 22, Algarve',15,'LIC-PT-005');

-- Embarcações
INSERT INTO vessels(name,registration,vessel_type,capacity_kg,home_port,captain_id) VALUES
('Marisqueira I','REG-001','Pesqueiro',8000,'Porto',1),
('Atlântico','REG-002','Atuneiro',12000,'Matosinhos',2),
('Nazaré III','REG-003','Barco de Cerco',5000,'Nazaré',3),
('Açoriano','REG-004','Lancha',800,'Ponta Delgada',4),
('Costa Azul','REG-005','Pesqueiro',6000,'Faro',5);

-- Espécies
INSERT INTO species(common_name,scientific_name,iucn_status,average_price_per_kg,sustainable,notes) VALUES
('Bacalhau','Gadus morhua','Near Threatened',3.50,FALSE,'Espécie sensível em algumas zonas'),
('Sardinha','Sardina pilchardus','Least Concern',1.20,TRUE,'Pesca sazonal'),
('Atum','Thunnus thynnus','Endangered',8.50,FALSE,'Captura regulada'),
('Cavala','Scomber scombrus','Least Concern',2.00,TRUE,''),
('Camarão','Penaeus vannamei','NA',6.00,TRUE,'Maioria em aquicultura'),
('Robalo','Dicentrarchus labrax','Near Threatened',7.00,TRUE,'Valorizado no mercado');

-- Zonas de pesca
INSERT INTO fishing_zones(name,code,description) VALUES
('Zona Norte','ZN','Plataforma continental norte'),
('Zona Centro','ZC','Águas costeiras centrais'),
('Zona Sul','ZS','Região sul e Algarve'),
('Açores','AC','Arquipélago dos Açores');

-- Viagens
INSERT INTO trips(vessel_id,start_date,end_date,departure_port,return_port,crew_count,notes) VALUES
(1,'2025-06-01','2025-06-03','Porto','Porto',8,'Viagem de rotina'),
(2,'2025-06-10','2025-06-18','Matosinhos','Matosinhos',12,'Pesca ao atum'),
(3,'2025-07-05','2025-07-05','Nazaré','Nazaré',6,'Pesca costeira'),
(4,'2025-08-15','2025-08-15','Ponta Delgada','Ponta Delgada',4,'Saída curta');

-- Capturas (exemplos)
INSERT INTO catches(trip_id,vessel_id,fisherman_id,species_id,zone_id,catch_date,weight_kg,quantity,gear_type,price_per_kg,quality_grade) VALUES
(1,1,1,2,1,'2025-06-01',120.50,300,'Rede de Emalhar',1.20,'A'),
(1,1,2,4,1,'2025-06-02',200.00,400,'Rede de Emalhar',2.00,'A'),
(2,2,2,3,2,'2025-06-12',1500.00,40,'Pesqueiro de Longa',8.50,'B'),
(3,3,3,1,3,'2025-07-05',350.00,25,'Cerco',3.50,'B'),
(4,4,4,5,4,'2025-08-15',80.00,800,'Armamento de Fundo',6.00,'A');

-- Vendas
INSERT INTO sales(catch_id,buyer,sale_date,total_price,notes) VALUES
(1,'Mercado do Bolhão','2025-06-02',120.50*1.20,'Venda direta ao mercado'),
(2,'Processadora Lda','2025-06-03',200.00*2.00,'Venda a processador'),
(3,'Exportador X','2025-06-20',1500.00*8.50,'Venda para exportação');

-- Licenças
INSERT INTO licenses(fisherman_id,license_type,issue_date,expiry_date,status) VALUES
(1,'Licença de Pesca Costeira','2023-01-01','2028-01-01','active'),
(2,'Licença de Pesca de Alto-Mar','2024-05-10','2029-05-10','active');

-- Trip crew
INSERT INTO trip_crew(trip_id,fisherman_id,role) VALUES
(1,1,'Capitão'),
(1,2,'Pescador'),
(2,2,'Capitão'),
(3,3,'Capitão'),
(4,4,'Capitão');

-- Pequeno resumo (opcional)
-- Agora existe uma base de dados "pesca_db" com esquema relacional, triggers que mantêm o peso total por viagem,
-- procedimentos simples para adicionar/editar/eliminar e vistas para relatórios.

-- FIM